import { LightningElement } from 'lwc';

export default class EventsHandsOnGP extends LightningElement {
    inputText;

    handleEventFromGC = (event) => {
        console.log('Event from GC');
        this.inputText = event.detail;
    }
}