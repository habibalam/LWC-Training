import { LightningElement } from 'lwc';

export default class EventsHandsOnParent extends LightningElement {
    inputText;

    handleChildEvent = (event) => {
        this.inputText = event.detail;
    }
}