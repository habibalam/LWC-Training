window.samplejs = (function() {
return {
 getList : function(){
    return ['This', 'That', 'Whatever'];
},
getAnotherList : function(){
    return ['When', 'How', 'If'];
}
};
}());